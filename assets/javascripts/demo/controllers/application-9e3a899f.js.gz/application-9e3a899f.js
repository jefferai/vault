Demo.ApplicationController = Ember.ObjectController.extend({
});
